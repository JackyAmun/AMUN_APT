import curses

class Calculator:
    def __init__(self, stdscr):
        self.stdscr = stdscr
        self.num1 = ''
        self.num2 = ''
        self.operation = ''
        self.result = ''
        self.current_input = 'num1'
        self.selected_button = 0  # 用于跟踪当前选中的按钮

        # 按钮布局
        self.buttons = [
            '1', '2', '3', '+',
            '4', '5', '6', '-',
            '7', '8', '9', '*',
            'C', '0', '=', '/'
        ]

    def draw_menu(self):
        self.stdscr.clear()
        curses.curs_set(0)
        h, w = self.stdscr.getmaxyx()

        # 创建一个框 (围绕整个界面)
        box_start_y = 1
        box_start_x = 2
        box_height = h - 4
        box_width = w - 4

        # 使用 addch 绘制框
        for i in range(box_height):
            self.stdscr.addch(box_start_y + i, box_start_x, curses.ACS_VLINE)  # 左边竖线
            self.stdscr.addch(box_start_y + i, box_start_x + box_width - 1, curses.ACS_VLINE)  # 右边竖线

        for j in range(box_width):
            self.stdscr.addch(box_start_y, box_start_x + j, curses.ACS_HLINE)  # 上边横线
            self.stdscr.addch(box_start_y + box_height - 1, box_start_x + j, curses.ACS_HLINE)  # 下边横线

        # 四个角
        self.stdscr.addch(box_start_y, box_start_x, curses.ACS_ULCORNER)  # 左上角
        self.stdscr.addch(box_start_y, box_start_x + box_width - 1, curses.ACS_URCORNER)  # 右上角
        self.stdscr.addch(box_start_y + box_height - 1, box_start_x, curses.ACS_LLCORNER)  # 左下角
        self.stdscr.addch(box_start_y + box_height - 1, box_start_x + box_width - 1, curses.ACS_LRCORNER)  # 右下角

        # 显示当前输入的式子
        if self.result:
            expression = f"{self.num1} {self.operation} {self.num2} = {self.result}"
        else:
            expression = f"{self.num1} {self.operation} {self.num2}" if self.operation else f"{self.num1}"
        self.stdscr.addstr(box_start_y + 1, box_start_x + 2, f"Expression: {expression}")

        # 绘制按钮
        start_y = box_start_y + 3
        start_x = box_start_x + 2
        for i, label in enumerate(self.buttons):
            if i == self.selected_button:
                self.stdscr.attron(curses.A_REVERSE)
                self.stdscr.addstr(start_y + i // 4, start_x + (i % 4) * 5, label)
                self.stdscr.attroff(curses.A_REVERSE)
            else:
                self.stdscr.addstr(start_y + i // 4, start_x + (i % 4) * 5, label)

        # 退出提示
        self.stdscr.addstr(h - 2, w // 2 - 12, "Press 'q' to quit")

        # 刷新屏幕
        self.stdscr.refresh()

    def handle_input(self, key):
        if key == curses.KEY_UP and self.selected_button > 3:
            self.selected_button -= 4
        elif key == curses.KEY_DOWN and self.selected_button < len(self.buttons) - 4:
            self.selected_button += 4
        elif key == curses.KEY_LEFT and self.selected_button % 4 > 0:
            self.selected_button -= 1
        elif key == curses.KEY_RIGHT and self.selected_button % 4 < 3:
            self.selected_button += 1
        elif key == ord(' '):
            self.select_button()
        elif key == ord('q'):
            return False
        return True

    def select_button(self):
        button = self.buttons[self.selected_button]
        if button.isdigit():
            if self.current_input == 'num1':
                self.num1 += button
            elif self.current_input == 'num2':
                self.num2 += button
        elif button in ['+', '-', '*', '/']:
            self.operation = button
            self.current_input = 'num2'
        elif button == '=':
            self.calculate()
            self.current_input = 'num1'  # 重置为输入第一个数字
        elif button == 'C':
            self.num1 = ''
            self.num2 = ''
            self.operation = ''
            self.result = ''
            self.current_input = 'num1'

    def calculate(self):
        try:
            num1 = float(self.num1)
            num2 = float(self.num2)
            if self.operation == '+':
                self.result = str(num1 + num2)
            elif self.operation == '-':
                self.result = str(num1 - num2)
            elif self.operation == '*':
                self.result = str(num1 * num2)
            elif self.operation == '/':
                if num2 == 0:
                    self.result = "Error: Division by zero"
                else:
                    self.result = str(num1 / num2)
            else:
                self.result = "Error: Invalid operation"
        except ValueError:
            self.result = "Error: Invalid input"

    def run(self):
        while True:
            self.draw_menu()
            key = self.stdscr.getch()

            if not self.handle_input(key):
                break

def main(stdscr):
    Calculator(stdscr).run()

if __name__ == "__main__":
    curses.wrapper(main)
